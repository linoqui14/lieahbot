
import 'dart:math';

import 'package:ez_bot_guid/controller/controller.dart';
import 'package:ez_bot_guid/custom_widgets/custom_texfield.dart';
import 'package:ez_bot_guid/custom_widgets/custom_textbutton.dart';
import 'package:ez_bot_guid/tools/my_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as OSM;
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ntp/ntp.dart';
import 'package:uuid/uuid.dart';
import '../model/transactions.dart';
import '../model/user.dart';
import 'package:intl/intl.dart';
import 'package:chat_bubbles/chat_bubbles.dart';


class Family extends StatefulWidget{
  Family({Key? key,required this.userModel}) : super(key: key);
  UserModel userModel;

  @override
  State<Family> createState() => _FamilyState();

}

class _FamilyState extends State<Family> {

  late DateTime _ntpTime;

  Future<String> GetAddressFromLatLong(LatLng pos)async {
    List<Placemark> placemarks = await placemarkFromCoordinates(pos.latitude, pos.longitude);
    Placemark place = placemarks[0];
    return '${place.street}, ${place.subLocality}, ${place.locality}, ${place.postalCode}, ${place.country}';

  }

  @override
  void initState() {


    super.initState();
  }
  OSM.MapController controller = OSM.MapController(
      initMapWithUserPosition: false,
      initPosition: OSM.GeoPoint(latitude: 0,longitude: 0)
  );
  TextEditingController messageController = TextEditingController();
  TextEditingController familyNumber = TextEditingController();
  TextEditingController destination = TextEditingController();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: TabBarView(
          children: [
            SingleChildScrollView(
              child: SizedBox(
                height: MediaQuery.of(context).size.height,
                child: Container(
                  height: MediaQuery.of(context).size.height,
                  color: Colors.black87,
                  child: Column(
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.all(10),
                          // color: Colors.amber,
                          child: StreamBuilder<DocumentSnapshot>(
                              stream: LiveLocationController.getLiveLocation(id: widget.userModel.id),
                              builder: (context,snapshot) {
                                if(!snapshot.hasData)return Center(child: CircularProgressIndicator(),);
                                LiveLocation liveLocation = LiveLocation.toObject(snapshot.data!.data());
                                controller.changeLocation(OSM.GeoPoint(latitude: liveLocation.lat, longitude: liveLocation.long));
                                controller.setZoom(zoomLevel: 18);
                                String address = "";
                                return StatefulBuilder(
                                    builder: (context,setState) {
                                      GetAddressFromLatLong(LatLng(liveLocation.lat, liveLocation.long )).then((value){
                                        setState((){
                                          address = value;
                                        });
                                      });
                                      return Column(
                                        children: [
                                          CustomTextField(
                                            rBottomRight: 0,
                                            rBottomLeft: 0,
                                            color: MyColors.deadBlue,
                                            readonly: true,
                                            hint: "Current Location",
                                            padding: EdgeInsets.zero,
                                            controller: TextEditingController(text: address),
                                          ),

                                          Expanded(
                                              child: OSM.OSMFlutter(
                                                onMapIsReady: (isReady){

                                                },

                                                onLocationChanged: (point){
                                                  controller.setZoom(stepZoom: 18);
                                                },
                                                controller:controller,
                                                trackMyPosition: false,
                                                initZoom: 19,
                                                minZoomLevel: 10,
                                                maxZoomLevel:19,
                                                stepZoom: 1.0,
                                                userLocationMarker: OSM.UserLocationMaker(
                                                  personMarker: OSM.MarkerIcon(
                                                    icon: Icon(
                                                      Icons.location_history_rounded,
                                                      color: Colors.red,
                                                      size: 48,
                                                    ),
                                                  ),
                                                  directionArrowMarker: OSM.MarkerIcon(
                                                    icon: Icon(
                                                      Icons.double_arrow,
                                                      size: 48,
                                                    ),
                                                  ),
                                                ),
                                                roadConfiguration:OSM. RoadConfiguration(
                                                  startIcon: OSM.MarkerIcon(
                                                    icon: Icon(
                                                      Icons.person,
                                                      size: 64,
                                                      color: Colors.brown,
                                                    ),
                                                  ),
                                                  roadColor: Colors.yellowAccent,
                                                ),
                                                markerOption: OSM.MarkerOption(
                                                    defaultMarker: OSM.MarkerIcon(
                                                      icon: Icon(
                                                        Icons.person_pin_circle,
                                                        color: Colors.blue,
                                                        size: 56,
                                                      ),
                                                    )
                                                ),
                                              )
                                          ),
                                        ],
                                      );
                                    }
                                );
                              }
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.all(10),
                          child: StatefulBuilder(
                              builder: (context,setState) {
                                return Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomTextField(
                                      rBottomRight: 0,
                                      rBottomLeft: 0,
                                      color: MyColors.deadBlue,
                                      hint: "Set Destination",
                                      padding: EdgeInsets.zero,
                                      controller: destination,
                                      suffix:CustomTextButton(
                                        width: 50,
                                        rTl: 0,
                                        rBL: 0,
                                        rBR: 0,
                                        color: MyColors.deadBlue,
                                        text: "Set",
                                        onPressed: (){
                                          var uuid = Uuid();
                                          GeocodingPlatform.instance.locationFromAddress(destination.text).then((loc) {
                                            MyDestinationController.upSert(destinationm: MyDestination(userID: widget.userModel.id, long: loc.first.longitude, lat: loc.first.longitude, time:0 ));
                                            setState((){
                                              // destination.text = "";
                                            });
                                          });
                                        },
                                      ) ,
                                    ),
                                    CustomTextField(
                                      rBottomRight: 0,
                                      rBottomLeft: 0,
                                      color: MyColors.deadBlue,
                                      hint: "Set Family Number",
                                      padding: EdgeInsets.zero,
                                      controller: familyNumber,
                                      suffix:CustomTextButton(
                                        width: 50,
                                        rTl: 0,
                                        rBL: 0,
                                        rBR: 0,
                                        rTR: 0,
                                        color: MyColors.deadBlue,
                                        text: "Set",
                                        onPressed: (){
                                          setState((){
                                            widget.userModel.familyNumber = familyNumber.text;
                                            UserController.upSert(user: widget.userModel);
                                            familyNumber.text = "";
                                          });

                                        },
                                      ) ,
                                    ),
                                    Expanded(
                                      child: Container(
                                        color: Colors.white.withAlpha(250),
                                        child: StreamBuilder<QuerySnapshot>(
                                            stream: MessageController.getMessages(id: widget.userModel.id),
                                            builder: (context,snapshot) {
                                              if(!snapshot.hasData)return Center(child: CircularProgressIndicator(),);
                                              if(snapshot.data!.docs.isEmpty)return Center(child: CircularProgressIndicator(),);
                                              List<Message> messages = [];
                                              List<String> messegesStr = [];
                                              snapshot.data!.docs.forEach((element) {
                                                Message message = Message.toObject(element.data());
                                                messages.add(message);
                                                messegesStr.add(message.message);
                                              });
                                              messages.sort((a,b)=>b.time.compareTo(a.time));

                                              return StatefulBuilder(
                                                  builder: (context,setState) {
                                                    return ListView(
                                                      reverse: true,
                                                      children: messages.map((message){
                                                        return Column(
                                                          children: [
                                                            Text(DateFormat.yMMMEd().add_jms().format(DateTime.fromMillisecondsSinceEpoch(message.time))),
                                                            BubbleSpecialThree(
                                                              text:message.message,
                                                              color: message.isFamily?Color(0xFF1B97F3):Colors.blueGrey,
                                                              isSender: message.isFamily,
                                                              textStyle: TextStyle(
                                                                  color: Colors.white,
                                                                  fontSize: 16
                                                              ),
                                                            ),
                                                          ],
                                                        );
                                                      }).toList(),
                                                    );
                                                  }
                                              );
                                            }
                                        ),
                                      ),
                                    ),
                                    CustomTextField(
                                      rTopRight: 0,
                                      rTopLeft: 0,
                                      color: MyColors.deadBlue,
                                      hint: "Message",
                                      padding: EdgeInsets.zero,
                                      controller: messageController,
                                      suffix:CustomTextButton(
                                        width: 50,
                                        rTl: 0,
                                        rBL: 0,
                                        color: Colors.transparent,
                                        text: "Send",
                                        onPressed: (){
                                          var uuid = Uuid();
                                          NTP.now().then((value) {
                                            setState(() {
                                              Message messagem = Message(chatID: widget.userModel.id, id: uuid.v1(), message: messageController.text, isFamily: true, time: value.millisecondsSinceEpoch);
                                              MessageController.upSert(messagem: messagem);
                                              messageController.text = "";
                                            });

                                          });

                                        },

                                      ) ,
                                    )
                                  ],
                                );


                              }
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
            Container(
              color: Colors.black87,
              height: double.infinity,
              child: StreamBuilder<QuerySnapshot>(
                stream: MyDestinationController.getDestinationWhereUserID(id: widget.userModel.id),
                builder: (context,snapshot){
                  if(!snapshot.hasData)return Center(child: CircularProgressIndicator(),);
                  if(snapshot.data!.docs.isEmpty)return Center(child: CircularProgressIndicator(),);
                  List<MyDestination> myDestinations = [];
                  snapshot.data!.docs.forEach((element) {
                    MyDestination myDestination = MyDestination.toObject(element.data());
                    myDestinations.add(myDestination);
                  });
                  myDestinations.sort((b,a)=>a.time.compareTo(b.time));
                  return ListView(
                        children: myDestinations.map((e) {

                          return FutureBuilder<String>(
                            future: GetAddressFromLatLong(LatLng(e.lat, e.long)),
                            builder: (context,future){
                              if(!future.hasData)return Center(child: CircularProgressIndicator(),);
                              return Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.black45,

                                  ),
                                  margin: EdgeInsets.all(5),
                                  padding: EdgeInsets.all(10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(future.data!,style: TextStyle(color: Colors.white,fontSize: 15,fontWeight: FontWeight.bold),),
                                      Text(DateFormat.yMMMMd().add_jms().format(DateTime.fromMillisecondsSinceEpoch(e.time)),style: TextStyle(color: Colors.white,fontWeight: FontWeight.w100),),
                                    ],
                                  )
                              );
                            },
                          );
                        }).toList(),
                  );
                },
              ),
            )
          ],
        ),
        bottomNavigationBar: Container(
          color: Colors.black87,
          height: 50,
          child: TabBar(
            tabs: [
              Icon(Icons.dashboard),
              Icon(Icons.query_stats),
            ],
          ),
        ),
      ),
    );
  }
}
