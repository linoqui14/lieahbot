



import 'dart:async';
import 'dart:math';

import 'package:ez_bot_guid/custom_widgets/custom_texfield.dart';
import 'package:ez_bot_guid/custom_widgets/custom_textbutton.dart';
import 'package:ez_bot_guid/model/transactions.dart';
import 'package:ez_bot_guid/model/user.dart';
import 'package:ez_bot_guid/tools/my_colors.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ez_bot_guid/util/tts.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as OSM;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:ntp/ntp.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:uuid/uuid.dart';
import 'package:telephony/telephony.dart';
import '../controller/controller.dart';
import 'login.dart';

class Home extends StatefulWidget{
  Home({Key? key,required this.userModel}) : super(key: key);
  UserModel userModel;


  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home>{
  final Telephony telephony = Telephony.instance;
  late FlutterTts flutterTts;
  late DateTime _ntpTime;
  String mode = "",currentMode = "";
  TextEditingController currentLocation = TextEditingController();
  TextEditingController destination = TextEditingController();
  bool dragup = false;
  bool dragdown = false;
  bool isManualSetLocation = false;
  bool send = false;

  SpeechToText _speechToText = SpeechToText();
  bool _speechEnabled = false;
  String _lastWords = '';
  bool onlyOnce = false;


  Future<Position> _getGeoLocationPosition() async {
    bool serviceEnabled;
    LocationPermission permission;
    String location ='Null, Press Button';
    String address = 'search';
    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      await Geolocator.openLocationSettings();
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {

        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    // continue accessing the position of the device.
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }
  Future<String> GetAddressFromLatLong(LatLng position)async {
    List<Placemark> placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);

    Placemark place = placemarks[0];
    return '${place.street}, ${place.subLocality}, ${place.locality}, ${place.postalCode}, ${place.country}';

  }

  void _initSpeech() async {
    _speechEnabled = await _speechToText.initialize();
    setState(() {});
  }
  void _startListening() async {
    await _speechToText.listen(onResult: _onSpeechResult);
    setState(() {});
  }
  void _stopListening() async {
    await _speechToText.stop();
    setState(() {});
  }
  void _onSpeechResult(SpeechRecognitionResult result) {
    setState(() {
      _lastWords = result.recognizedWords;
    });
  }


  int count = 0;
  int updateLocationCount = 0;
  late Timer _timer;
  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _timer =  Timer.periodic(
        oneSec,
            (Timer timer) {
          _timer = timer;
          if(count==1){
            flutterTts.speak("Welcome to  LAYA BOT! Double tap at the bottom of the device to manually use the device. single tap to automatic. swipe up to know your current location. Swipe down to repeat the message.Swipe left to repeat last family message.Hold bottom right corner of your phone and speak to reply to your family");
            // _timer.cancel();
          }
          if(updateLocationCount==60){
            _getGeoLocationPosition().then((value) {
              var uuid = Uuid();
              MyLocation myLocation = MyLocation(id: uuid.v1(), userID: widget.userModel.id, long: value.longitude, lat: value.latitude, time: DateTime.now().millisecondsSinceEpoch);
              LiveLocation liveLocation = LiveLocation(id: widget.userModel.id, long: value.longitude, lat: value.latitude);
              LiveLocationController.upSert(liveLocationm: liveLocation);
              MyLocationController.upSert(myLocationm: myLocation);
            });
            updateLocationCount = 0;
          }
          count++;
          updateLocationCount++;

        });
  }
  @override
  void initState() {
    NTP.now().then((value) {
      setState(() {
        _ntpTime = value;
      });

    });

    _initSpeech();
    // speech = speechToText.SpeechToText();
    print(widget.userModel.status);
    _getGeoLocationPosition().then((value) {
      GetAddressFromLatLong(LatLng(value.latitude, value.longitude)).then((address) {
        setState(() {
          currentLocation.text = address;
        });
      });
    });

    flutterTts = FlutterTts();
    // flutterTts.setLanguage("fil-PH");
    // flutterTts.setVoice({"fil-PH-Standard-A":"FEMALE"});
    startTimer();
    flutterTts.setCompletionHandler(() {
      setState(() {
        onlyOnce = false;
      });
      print("Complete!");

      if(mode == "Automatic" &&currentMode!="Automatic"){
        flutterTts.speak("This is Automatic mode, please speak to where you wanted to go. Or you can let your family member to select it for you.Please find assistance to enable GPS. Swipe up to get current location address. Single tap to repeat this message.Hold down and speak to set your destination.");
        setState(() {
          currentMode = "Automatic";
        });
      }
      else if(mode == "Manual" &&currentMode!="Manual"){
        flutterTts.speak("This is Manual mode, please be careful,double tap to repeat this message");
        setState(() {
          currentMode = "Manual";
        });
      }
      else if(mode == "Speak" &&currentMode!="Speak"){
        _speechToText.isNotListening ? _startListening.call() : _stopListening.call();
        setState(() {
          currentMode = "Speak";
        });
      }
      if(dragup){
        setState(() {
          dragup = false;
        });

      }
    });
    flutterTts.setStartHandler(() {
      print("START");
    });

    // TODO: implement initState
    super.initState();
  }
  @override
  void dispose() {
    flutterTts.stop();
    super.dispose();
  }
  OSM.MapController controller = OSM.MapController(
    initMapWithUserPosition: true,
    initPosition: OSM.GeoPoint(latitude: 0, longitude:0),
    // areaLimit: BoundingBox( east: 10.4922941, north: 47.8084648, south: 45.817995, west: 5.9559113,),
  );
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height ,
          child: Column(

            children: [
              Stack(
                children: [
                  StreamBuilder<Position>(
                      stream: Geolocator.getPositionStream(),
                      builder: (context,snapShot) {
                        if(!snapShot.hasData)return Center(child: CircularProgressIndicator(),);
                        // controller.setZoom(stepZoom: 5);
                        return SizedBox(
                            height:  MediaQuery.of(context).size.height*0.3,
                            child: OSM.OSMFlutter(
                              onMapIsReady: (isReady){

                              },
                              onLocationChanged: (point){
                                controller.setZoom(stepZoom: 18);
                              },
                              controller:controller,
                              trackMyPosition: true,
                              initZoom: 19,
                              minZoomLevel: 10,
                              maxZoomLevel:19,
                              stepZoom: 1.0,
                              userLocationMarker: OSM.UserLocationMaker(
                                personMarker: OSM.MarkerIcon(
                                  icon: Icon(
                                    Icons.location_history_rounded,
                                    color: Colors.red,
                                    size: 48,
                                  ),
                                ),
                                directionArrowMarker: OSM.MarkerIcon(
                                  icon: Icon(
                                    Icons.double_arrow,
                                    size: 48,
                                  ),
                                ),
                              ),
                              roadConfiguration: OSM.RoadConfiguration(
                                startIcon: OSM.MarkerIcon(
                                  icon: Icon(
                                    Icons.person,
                                    size: 64,
                                    color: Colors.brown,
                                  ),
                                ),
                                roadColor: Colors.yellowAccent,
                              ),
                              markerOption: OSM.MarkerOption(
                                  defaultMarker: OSM.MarkerIcon(
                                    icon: Icon(
                                      Icons.person_pin_circle,
                                      color: Colors.blue,
                                      size: 56,
                                    ),
                                  )
                              ),
                            )

                        );
                      }
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomTextButton(
                        rTl: 0,
                        rBL: 0,
                        color: MyColors.deadBlue,
                        onHold: (){
                          widget.userModel.status = "logout";
                          UserController.upSert(user: widget.userModel);
                          flutterTts.speak("The user is logging out.").whenComplete(() {
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(builder: (context) => Login()),
                                  (Route<dynamic> route) => false,
                            );

                            flutterTts.stop();
                          });

                        },
                        text: "Hold to logout",

                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: CustomTextButton(
                            width: 140,
                            padding: EdgeInsets.zero,
                            rBR: 0,
                            rTR: 0,
                            color: MyColors.deadBlue,
                            onHold: (){
                              setState(() {
                                isManualSetLocation?isManualSetLocation=false:isManualSetLocation=true;
                                flutterTts.speak(isManualSetLocation?"Gesture disabled on manual destination set":"Gesture enabled");
                              });

                            },
                            text: "Manual set location",
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              Expanded(
                child: Stack(
                  children: [
                    StreamBuilder<QuerySnapshot>(
                      stream: MessageController.getMessages(id: widget.userModel.id),
                      builder: (context,snapshot){
                        if(!snapshot.hasData)return Center();
                        if(snapshot.data!.docs.isEmpty)return Center();
                        snapshot.data!.docs.forEach((message) {
                          Message messagem = Message.toObject(message.data());
                          if(!messagem.read&&messagem.isFamily) flutterTts.speak("Message from family: "+messagem.message);
                          messagem.read = true;
                          MessageController.upSert(messagem: messagem);
                        });
                        return Center();
                      },
                    ),
                    StreamBuilder<DocumentSnapshot>(
                      stream:  MyDestinationController.getDestination(id: widget.userModel.id),
                      builder: (context,snapshot){
                        bool isSetDestination = true;
                        if(!snapshot.hasData) isSetDestination = false;
                        if(mode=="Automatic"){
                          String destinationNew = "";

                          MyDestination myDestination = MyDestination.toObject(snapshot.data!.data());

                          GetAddressFromLatLong(LatLng(myDestination.lat, myDestination.long)).then((value){
                            if(destination.text!=value){
                              destination.text = value;
                              _getGeoLocationPosition().then((pos){
                                var addresses = GeocodingPlatform.instance.locationFromAddress(destination.text);
                                addresses.then((add){
                                  double desLong = add.first.longitude;
                                  double desLat = add.first.latitude;
                                  print(add);
                                  flutterTts.speak("Your destination: "+destination.text);
                                  controller.drawRoad(
                                    OSM.GeoPoint(latitude: pos.latitude, longitude: pos.longitude),
                                    OSM.GeoPoint(latitude: desLat, longitude: desLong),
                                    roadType: OSM.RoadType.foot,
                                    roadOption: OSM.RoadOption(
                                      roadWidth: 10,
                                      roadColor: Colors.deepPurple,
                                      showMarkerOfPOI: false,
                                      zoomInto: true,
                                    ),
                                  ).then((value) {
                                    mode = "Automatic";
                                    currentMode = "";
                                    MyDestinationController.upSert(destinationm: MyDestination(userID: widget.userModel.id, long: desLong, lat: desLat, time: DateTime.now().millisecondsSinceEpoch));
                                    print(value.route);
                                  });

                                });
                              });
                            }
                          });


                          print("asdasd");
                        }

                        return Center();
                      },
                    ),
                    if(mode=="Automatic"||isManualSetLocation||mode=="Speak")
                      Container(
                        color: Colors.black87,
                        // padding: EdgeInsets.only(top: 300),
                        child: Column(
                          children: [

                            Padding(
                              padding: const EdgeInsets.all(10),
                              child: Text("Double tap at the bottom of the device to manually use the device, single tap to automatic. Swipe down to repeat the message.Swipe left to repeat last family message.Hold bottom right corner of your phone and speak to reply to your family",textAlign: TextAlign.center,style: TextStyle(color: Colors.white),),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 60),
                              child: Column(
                                children: [
                                  Text(mode,textAlign: TextAlign.center,style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold),),
                                  Text("Mode",textAlign: TextAlign.center,style: TextStyle(color: Colors.white,fontSize: 13,fontWeight: FontWeight.bold),),
                                ],
                              ),
                            ),
                            if(mode=="Automatic")
                              CustomTextField(
                                  readonly: true,
                                  icon: Icons.my_location,
                                  color: MyColors.skyBlueDead,
                                  hint: "Current Location",
                                  padding: EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                                  controller: currentLocation),
                            CustomTextField(
                                suffix: CustomTextButton(
                                  rBL: 0,
                                  rTl: 0,
                                  text: "Go",
                                  width: 50,
                                  color: MyColors.deadBlue,
                                  onHold: (){
                                    _getGeoLocationPosition().then((pos){
                                      var addresses = GeocodingPlatform.instance.locationFromAddress(destination.text);
                                      addresses.then((add){
                                        double desLong = add.first.longitude;
                                        double desLat = add.first.latitude;
                                        print(add);
                                        flutterTts.speak("Your destination: "+destination.text);
                                        controller.drawRoad(
                                          OSM.GeoPoint(latitude: pos.latitude, longitude: pos.longitude),
                                          OSM.GeoPoint(latitude: desLat, longitude: desLong),
                                          roadType: OSM.RoadType.foot,
                                          roadOption: OSM.RoadOption(
                                            roadWidth: 10,
                                            roadColor: Colors.deepPurple,
                                            showMarkerOfPOI: false,
                                            zoomInto: true,
                                          ),
                                        ).then((value) {
                                          mode = "Automatic";
                                          currentMode = "";
                                          MyDestinationController.upSert(destinationm: MyDestination(userID: widget.userModel.id, long: desLong, lat: desLat, time: DateTime.now().millisecondsSinceEpoch));
                                          print(value.route);
                                        });

                                      });
                                    });

                                  },
                                ),
                                icon: Icons.location_on,
                                color: MyColors.skyBlueDead,
                                hint: "Destination",
                                padding: EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                                controller: destination
                            ),

                          ],
                        ),
                      ),
                    if(!isManualSetLocation)
                      GestureDetector(
                        onDoubleTap: (){
                          flutterTts.stop().then((value) {
                            flutterTts.speak("Manual mode");
                            setState(() {
                              mode = "Manual";
                              currentMode = "";
                            });
                          });

                        },
                        onLongPressStart: (details){
                          flutterTts.stop().then((value) {
                            setState(() {
                              flutterTts.speak("Speak after this message.Hold speak release");
                              mode = "Speak";
                              currentMode = "";

                            });
                          });

                        },
                        onLongPressEnd: (details){
                          flutterTts.stop().then((value) {
                            _getGeoLocationPosition().then((pos){
                              var addresses = GeocodingPlatform.instance.locationFromAddress(_lastWords);
                              addresses.then((add){
                                double desLong = add.first.longitude;
                                double desLat = add.first.latitude;
                                print(add);
                                flutterTts.speak("Your destination: "+_lastWords);
                                controller.drawRoad(
                                  OSM.GeoPoint(latitude: pos.latitude, longitude: pos.longitude),
                                  OSM.GeoPoint(latitude: desLat, longitude: desLong),
                                  roadType: OSM.RoadType.foot,
                                  roadOption: OSM.RoadOption(
                                    roadWidth: 10,
                                    roadColor: Colors.deepPurple,
                                    showMarkerOfPOI: false,
                                    zoomInto: true,
                                  ),
                                ).then((value) {
                                  MyDestinationController.upSert(destinationm: MyDestination(userID: widget.userModel.id, long: desLong, lat: desLat, time: DateTime.now().millisecondsSinceEpoch));
                                  print(value.route);
                                  mode = "Automatic";
                                  currentMode = "";
                                  setState(() {
                                    destination.text = _lastWords;
                                  });
                                });

                              });
                            });
                          });

                        },
                        onTap: (){
                          flutterTts.stop().then((value) {
                            flutterTts.speak("Automatic mode");
                            setState(() {
                              mode = "Automatic";
                              currentMode = "";
                            });
                          });

                        },
                        onVerticalDragUpdate: (dragdetails) async{
                          if(dragdetails.delta.direction<=0&&!dragup){
                            _getGeoLocationPosition().then((value) {
                              GetAddressFromLatLong(LatLng(value.latitude, value.longitude)).then((address) {
                                setState(() {
                                  currentLocation.text = address;
                                  flutterTts.speak("This is your current Location. "+address);
                                  dragup = true;
                                });
                              });
                            });
                          }
                          if(dragdetails.delta.direction>=1){
                            // listen();
                            setState(() {
                              dragdown = true;
                              flutterTts.speak("Double tap at the bottom of the device to manually use the device, single tap to automatic. Swipe down to repeat the message.Swipe left to repeat last family message.Hold bottom right corner of your phone and speak to reply to your family");

                            });
                          }
                        },
                        onHorizontalDragUpdate: (dragdetails){
                          if(dragdetails.delta.direction==0&&!onlyOnce){
                            _getGeoLocationPosition().then((value) {
                              GetAddressFromLatLong(LatLng(value.latitude, value.longitude)).then((address) {
                                setState(() {
                                  flutterTts.speak("Emergency! Emergency! Emergency! Fetch Me ASAP at"+address).whenComplete(() {
                                    //LAKBAYANNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
                                    NTP.now().then((value) {
                                      var uuid = Uuid();
                                      Message message = Message(chatID: widget.userModel.id,message: "Emergency! Emergency! Emergency! Fetch Me ASAP at"+address+"\nTime:"+DateFormat.yMMMEd().add_jms().format(value),read: false,isFamily: false,time:value.microsecondsSinceEpoch, id: uuid.v1());
                                      MessageController.upSert(messagem: message);
                                      print(widget.userModel.familyNumber);
                                      if(widget.userModel.familyNumber.isNotEmpty){
                                        telephony.sendSms(to: widget.userModel.familyNumber, message: "Emergency! Emergency! Emergency! Fetch Me ASAP at"+address+"\nTime:"+DateFormat.yMMMEd().add_jms().format(value)).whenComplete(() {

                                        });
                                      }
                                    });


                                  });
                                });
                              });
                            });
                          }
                          else if(dragdetails.delta.direction>0){
                            MessageController.getMessagesDoC(id: widget.userModel.id).then((value){
                              if(value.docs.isNotEmpty){
                                List<Message> messages = [];
                                value.docs.forEach((element) {
                                  Message messagem = Message.toObject(element.data());
                                  messages.add(messagem);
                                });

                                flutterTts.speak("Message from family: "+messages.lastWhere((element) => element.isFamily).message);
                              }
                            });
                          }
                          print(dragdetails.delta.direction.toInt());
                          setState(() {
                            onlyOnce = true;
                          });
                        },
                        child: Container(
                          color: Colors.black87,
                          height: double.infinity,
                          width: double.infinity,
                          alignment: Alignment.topCenter,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(10),
                                child: Text("Double tap at the bottom of the device to manually use the device, single tap to automatic. Swipe down to repeat the message.Swipe left to repeat last family message.Hold bottom right corner of your phone and speak to reply to your family",textAlign: TextAlign.center,style: TextStyle(color: Colors.white),),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 60),
                                child: Column(
                                  children: [
                                    Text(mode,textAlign: TextAlign.center,style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold),),
                                    Text("Mode",textAlign: TextAlign.center,style: TextStyle(color: Colors.white,fontSize: 13,fontWeight: FontWeight.bold),),
                                  ],
                                ),
                              ),
                              if(mode=="Automatic"||mode=="Speak")
                                CustomTextField(
                                    readonly: true,
                                    icon: Icons.my_location,
                                    color: MyColors.skyBlueDead,
                                    hint: "Current Location",
                                    padding: EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                                    controller: currentLocation),
                              if(mode=="Automatic"||mode=="Speak")
                                CustomTextField(
                                    readonly: true,
                                    icon: Icons.location_on,
                                    color: MyColors.skyBlueDead,
                                    hint: "Destination",
                                    padding: EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                                    controller: destination
                                ),
                              Expanded(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    GestureDetector(
                                      onLongPressStart: (details){
                                        flutterTts.speak("Speak after this message.Hold speak release").then((value) {
                                          setState(() {
                                            mode = "Speak";
                                            currentMode = "";
                                          });
                                        });
                                      },
                                      onLongPressEnd: (details){
                                        flutterTts.speak("Your message: "+_lastWords).whenComplete(() {
                                          flutterTts.speak("Tap on bottom right corner of the device to send. double tap to cancel");
                                          setState(() {
                                            send = true;
                                          });
                                        });

                                      },
                                      onDoubleTap: (){
                                        flutterTts.speak("Send message canceled").whenComplete((){
                                          setState(() {
                                            send = false;
                                          });
                                        });

                                      },
                                      onTap: (){
                                        if(send){
                                          flutterTts.speak("Successfully sent").whenComplete((){
                                            var uuid = Uuid();
                                            NTP.now().then((value) {
                                              setState(() {
                                                Message message = Message(chatID: widget.userModel.id,message: _lastWords,read: false,isFamily: false,time:value.microsecondsSinceEpoch, id: uuid.v1());
                                                MessageController.upSert(messagem: message);


                                                  send = false;

                                              });

                                            });

                                          });

                                        }
                                      },
                                      child: CustomTextButton(
                                        rTl: 50,
                                        rBL: 50,
                                        rTR: 0,
                                        text: "Reply",
                                        height: MediaQuery.of(context).size.height*.05,
                                        width: 200,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),

                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

}