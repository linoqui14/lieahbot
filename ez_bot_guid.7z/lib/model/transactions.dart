

class LiveLocation{
  String id;
  double long,lat;

  LiveLocation({required this.id, required this.long, required this.lat});
  Map<String,dynamic> toMap(){
    return {
      'id':id,
      'long':long,
      'lat':lat,
    };
  }

  static LiveLocation toObject(data){
    return LiveLocation(
        id:data['id'],
        long:data['long'],
        lat:data['lat']
    );
  }
}

class MyLocation{
  String id,userID;
  double long,lat;
  int time;
  MyLocation({required this.id,required this.userID, required this.long, required this.lat,required this.time});

  Map<String,dynamic> toMap(){
    return {
      'id':id,
      'userID':userID,
      'long':long,
      'lat':lat,
      'time':time,
    };
  }

  static MyLocation toObject(data){
    return MyLocation(
      id:data['id'],
      long:data['long'],
      lat:data['lat'],
      userID:data['userID'],
      time:data['time'],
    );
  }

}
class MyDestination{
  String userID;
  double long,lat;
  int time;
  MyDestination({required this.userID, required this.long, required this.lat,required this.time});

  Map<String,dynamic> toMap(){
    return {
      'userID':userID,
      'long':long,
      'lat':lat,
      'time':time,
    };
  }

  static MyDestination toObject(data){
    return MyDestination(
      long:data['long'],
      lat:data['lat'],
      userID:data['userID'],
      time:data['time'],
    );
  }

}


class Chat{
  String userID;
  List<dynamic> messages;

  Chat({required this.userID,required this.messages});

  Map<String,dynamic> toMap(){
    return {
      'userID':userID,
      'messages':messages,

    };
  }

  static Chat toObject(data){
    return Chat(
      userID:data['userID'],
      messages:data['messages'],

    );
  }



}

class Message{
  String chatID,id,message;
  bool isFamily,read;
  int time;

  Message({required this.chatID,required this.id,required this.message,required this.isFamily,required this.time,this.read = false});



  Map<String,dynamic> toMap(){
    return {
      'id':id,
      'chatID':chatID,
      'message':message,
      'isFamily':isFamily,
      'time':time,
      'read':read,
    };
  }

  static Message toObject(data){
    return Message(
      id:data['id'],
      chatID:data['chatID'],
      message:data['message'],
      isFamily:data['isFamily'] ,
      time:data['time'],
      read:data['read'],

    );
  }

}
